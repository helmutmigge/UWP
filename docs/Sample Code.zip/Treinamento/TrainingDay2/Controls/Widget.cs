﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingDay2.Controls
{
    public class Widget
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string color;

        public string Color
        {
            get { return color; }
            set { color = value; }
        }

        private string image;

        public string Image
        {
            get { return image; }
            set { image = value; }
        }

    }
}
