﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using TrainingDay2.Controls;
using TrainingDay2.Controls.SplitView;
using TrainingDay2.Items;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace TrainingDay2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void OnGoToDataBinding(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(DataBindingPage));

        }

        private void OnGoToElementBinding(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(ElementBindingPage));

        }

        private void OnGoToTemplateBinding(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(TemplateBindingPage));

        }

        private void OnGoToConverter(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(ConverterPage));

        }



        private void OnGoToItemsControl(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(ItemsControlPage));
        }

        private void OnGoToDataTemplate(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(DataTemplatePage));
        }

        private void OnGoToListView(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(ListViewPage));
        }

        private void OnGoToGridView(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(GridViewPage));
        }

        private void OnGoToFlipView(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(FlipViewPage));
        }

        private void OnGoToFlipView2(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(FlipView2Page));
        }

        private void OnGoToDataTemplateSelector(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(DataTemplateSelectorPage));
        }

        private void OnGoToFlyout(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(FlyoutPage));
        }

        private void OnGoToCommandBar(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(CommandBarPage));
        }

        private void OnGoToSplitView(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(SplitViewPage));
        }

        private void OnGoToHub(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(HubPage));
        }

        private void OnGoToPivot(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(PivotPage));
        }
    }
}
