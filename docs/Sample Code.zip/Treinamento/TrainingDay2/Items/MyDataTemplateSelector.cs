﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace TrainingDay2.Items
{
    public class MyDataTemplateSelector : DataTemplateSelector
    {
        public DataTemplate MediaItemTemplate { get; set; }
        public DataTemplate PersonItemTemplate { get; set; }

        protected override DataTemplate SelectTemplateCore(object item, DependencyObject container)
        {
            if (item != null && item is Media)
            {
                return MediaItemTemplate;
            }
            else
            {
                return PersonItemTemplate;
            }
        }
    }
}
