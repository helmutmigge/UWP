﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingDay2.Items
{
    public class Media
    {
        public string ImagePath { get; set; }
    }
}
