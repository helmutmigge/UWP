﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainingDay2;

namespace TrainingDay2.Items
{
    public class MockData
    {
        public List<Person> People
        {
            get
            {
                var temp = new List<Person>();
                var data = new Data();
                foreach (var item in data.People)
                {
                    item.Fullname = "Temp_" + item.Fullname;
                    temp.Add(item);
                }
                return temp;
            }
        }

        public List<Media> Medias
        {
            get
            {
                var list = new List<Media>();

                for (int i = 0; i < 50; i++)
                {
                    string path = string.Format("ms-appx:///Assets/img{0}.jpg", 1 + (i % 3));
                    list.Add(new Media { ImagePath = path });
                }
                return list;
            }
        }
    }
}
