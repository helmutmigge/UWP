﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainingDay2;

namespace TrainingDay2.Items
{
    public class Data
    {
        public List<Person> People
        {
            get
            {
                return new List<Person>()
                {
                    new Person {Fullname = "Daniel Barros", Nickname = "Urso", Age = 27 },
                    new Person {Fullname = "João Paulo", Nickname = "JP", Age = 29 },
                    new Person {Fullname = "José Carlos", Nickname = "Zoeiro", Age = 28 },
                    new Person {Fullname = "Felipe Duarte", Nickname = "Irmão de Zeca", Age = 29 },
                    new Person {Fullname = "Antônio Cavalcante", Nickname = "Toin", Age = 35 },
                    new Person {Fullname = "Leonardo Martins", Nickname = "Ninja", Age = 45 },
                    new Person {Fullname = "Fernando Lúcio", Nickname = "Adnet", Age = 17 }
                };
            }
        }

        public List<Media> Medias
        {
            get
            {
                var list = new List<Media>();

                for (int i = 0; i < 50; i++)
                {
                    string path = string.Format("ms-appx:///Assets/img{0}.jpg", 1 + (i % 3));
                    list.Add(new Media { ImagePath = path });
                }
                return list;
            }
        }

        public List<object> Mixed
        {
            get
            {
                var list = new List<object>();

                var people = People;
                Random rnd = new Random();

                for (int i = 0; i < 50; i++)
                {
                    if (rnd.Next(0, 2) == 0)
                    {
                        string path = string.Format("ms-appx:///Assets/img{0}.jpg", 1 + (i % 3));
                        list.Add(new Media { ImagePath = path });
                    }
                    else
                    {
                        list.Add(people[rnd.Next(0, people.Count)]);
                    }
                }
                return list;
            }
        }
    }
}
