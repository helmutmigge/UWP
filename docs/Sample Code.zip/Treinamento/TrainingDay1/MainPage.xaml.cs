﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using XAMLBasic.Intro;
using XAMLBasic.Resources;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace XAMLBasic
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }


        private void OnGoToIntro(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(IntroPage));
        }

        private void OnGoToControls(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(StandardControlsPage));
        }


        private void OnGoToCanvasPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(CanvasPage));
        }

        private void OnGoToStackPanelPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(StackPanelPage));
        }

        private void OnGoToGridPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(GridPage));
        }

        private void OnGoToRelativePanelPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(RelativePanelPage));
        }

        private void OnGoToBorderPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(BorderPage));
        }

        private void OnGoToMixLayoutPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(MixLayoutPage));
        }

        private void OnGoToUserControlPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(UserControlPage));
        }






        private void OnGoToNavigationPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(NavigationPage));
        }

        private void OnGoToResourcesPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(ResourcesPage));
        }

        private void OnGoToStylesPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(StylesPage));
        }

        private void OnGoToTemplatePage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(TemplatePage));
        }

        private void OnGoToVisualStatesPage(object sender, RoutedEventArgs e)
        {
            NavFrame.Navigate(typeof(VisualStatesPage));
        }
    }
}
