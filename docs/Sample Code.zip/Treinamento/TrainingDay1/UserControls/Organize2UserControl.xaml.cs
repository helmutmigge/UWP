﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace XAMLBasic.UserControls
{
    public sealed partial class Organize2UserControl : UserControl
    {
        public Organize2UserControl()
        {
            this.InitializeComponent();
        }

        private async void button_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new MessageDialog("Clicked OK");
            await dialog.ShowAsync();

        }

        private async void button_Copy_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new MessageDialog("Clicked Cancel");
            await dialog.ShowAsync();

        }
    }
}
