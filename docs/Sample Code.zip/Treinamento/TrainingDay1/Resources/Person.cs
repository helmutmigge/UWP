﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XAMLBasic.Resources
{
    public class Person
    {
        public string Fullname { get; set; }
        public string Nickname { get; set; }
    }
}
