﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace TrainingDay3.Concept
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class CollectionBindingPage : Page
    {
        public CollectionBindingPage()
        {
            this.InitializeComponent();
            var list = new List<PersonDumb>()
                {
                    new PersonDumb {Fullname = "Daniel Barros", Nick = "Urso", Age = 27 },
                    new PersonDumb {Fullname = "João Paulo", Nick = "JP", Age = 29 },
                    new PersonDumb {Fullname = "José Carlos", Nick = "Zoeiro", Age = 28 },
                    new PersonDumb {Fullname = "Felipe Duarte", Nick = "Irmão de Zeca", Age = 29 },
                    new PersonDumb {Fullname = "Antônio Cavalcante", Nick = "Toin", Age = 35 },
                    new PersonDumb {Fullname = "Leonardo Martins", Nick = "Ninja", Age = 45 },
                    new PersonDumb {Fullname = "Fernando Lúcio", Nick = "Adnet", Age = 17 }
                };

            Data = new ObservableCollection<PersonDumb>(list);
        }

        private int count = 0;
        public ObservableCollection<PersonDumb> Data { get; set; }

        public PersonDumb SelectedItem { get; set; }

        private void OnAddItems(object sender, RoutedEventArgs e)
        {
            Data.Add(new PersonDumb { Fullname = "New Item" + count++ });
        }

        private void OnRemoveItems(object sender, RoutedEventArgs e)
        {
            if(listView.SelectedItem != null)
            {
                Data.Remove((PersonDumb)listView.SelectedItem);
            }
        }

        private void OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SelectedItem = (PersonDumb)listView.SelectedItem;
        }

        private void OnCreateNewList(object sender, RoutedEventArgs e)
        {
            Data = new ObservableCollection<PersonDumb>();
        }

        private void OnChangeItem(object sender, RoutedEventArgs e)
        {
            Data[0].Fullname = "Changed Value";
        }
    }

}
