﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace TrainingDay3.Concept
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class FullBindingSamplePage : Page,  INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged = delegate { };
        private void OnPropertyChanged(string propertyName)
        {
            this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }


        public FullBindingSamplePage()
        {
            this.InitializeComponent();
            var list = new List<Person>()
                {
                    new Person {Fullname = "Daniel Barros", Nick = "Urso", Age = 27 },
                    new Person {Fullname = "João Paulo", Nick = "JP", Age = 29 },
                    new Person {Fullname = "José Carlos", Nick = "Zoeiro", Age = 28 },
                    new Person {Fullname = "Felipe Duarte", Nick = "Irmão de Zeca", Age = 29 },
                    new Person {Fullname = "Antônio Cavalcante", Nick = "Toin", Age = 35 },
                    new Person {Fullname = "Leonardo Martins", Nick = "Ninja", Age = 45 },
                    new Person {Fullname = "Fernando Lúcio", Nick = "Adnet", Age = 17 }
                };

            Data = new ObservableCollection<Person>(list);
        }

        private int count = 0;
        private ObservableCollection<Person> data;
        public ObservableCollection<Person> Data
        {
            get
            {
                return data;
            }
            set
            {
                data = value;
                OnPropertyChanged("Data");
            }
        }

        private Person selectedItem;
        public Person SelectedItem
        {
            get
            {
                return selectedItem;
            }
            set
            {
                selectedItem = value;
                OnPropertyChanged("SelectedItem");
            }
        }

        private void OnAddItems(object sender, RoutedEventArgs e)
        {
            Data.Add(new Person { Fullname = "New Item" + count++ });
        }

        private void OnRemoveItems(object sender, RoutedEventArgs e)
        {
            if (listView.SelectedItem != null)
            {
                Data.Remove((Person)listView.SelectedItem);
            }
        }

        private void OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SelectedItem = (Person)listView.SelectedItem;
        }

        private void OnCreateNewList(object sender, RoutedEventArgs e)
        {
            Data = new ObservableCollection<Person>();
        }

        private void OnChangeItem(object sender, RoutedEventArgs e)
        {
            Data[0].Fullname = "Changed Value";
        }
    }
}
