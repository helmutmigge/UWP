﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingDay3.Concept
{
    public class PersonDumb
    {

        public string Fullname { get; set; }

        public string Nick { get; set; }

        public int Age { get; set; }
    }
}
