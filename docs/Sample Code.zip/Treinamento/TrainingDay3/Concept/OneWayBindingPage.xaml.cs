﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace TrainingDay3.Concept
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class OneWayBindingPage : Page
    {
        public OneWayBindingPage()
        {
            this.InitializeComponent();
        }

        public PersonDumb Data { get; set; } = new PersonDumb { Fullname = "João Paulo", Nick = "Jeips", Age = 28 };

        private async void button_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new MessageDialog(Data.Fullname);
            await dialog.ShowAsync();
        }
    }
}
