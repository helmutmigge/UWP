﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace TrainingDay3.Concept
{
    public class Person : INotifyPropertyChanged
    {

        private string fullname;
        public string Fullname
        {
            get
            {
                return fullname;
            }
            set
            {
                fullname = value;
                OnPropertyChanged("Fullname");
            }
        }



        private string nick;
        public string Nick
        {
            get
            {
                return nick;
            }
            set
            {
                nick = value;
                OnPropertyChanged("Nick");
            }
        }



        private int age;
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
                OnPropertyChanged("Age");
            }
        }




        public event PropertyChangedEventHandler PropertyChanged = delegate { };
        private void OnPropertyChanged(string propertyName)
        {
            this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
    
}
