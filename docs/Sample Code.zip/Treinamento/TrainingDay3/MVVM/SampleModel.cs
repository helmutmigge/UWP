﻿using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingDay3.MVVM
{
    public class SampleModel : BindableBase
    {

        private string fullname;
        public string Fullname
        {
            get { return fullname; }
            set { SetProperty(ref fullname, value); }
        }

        private string nick;
        public string Nick
        {
            get { return nick; }
            set { SetProperty(ref nick, value); }
        }


        private int age;
        public int Age
        {
            get { return age; }
            set { SetProperty(ref age, value); }
        }
    }
}
