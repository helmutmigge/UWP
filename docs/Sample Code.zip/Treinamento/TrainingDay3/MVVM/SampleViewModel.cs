﻿using Prism.Commands;
using Prism.Windows.Mvvm;
using Prism.Windows.Navigation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TrainingDay3.MVVM
{
    public class SampleViewModel : ViewModelBase
    {
        private int count = 0;

        public SampleViewModel()
        {
            InitializeMockData();
            InitializeCommands();
        }

        private void InitializeMockData()
        {
            var list = new List<SampleModel>()
                {
                    new SampleModel {Fullname = "Daniel Barros", Nick = "Urso", Age = 27 },
                    new SampleModel {Fullname = "João Paulo", Nick = "JP", Age = 29 },
                    new SampleModel {Fullname = "José Carlos", Nick = "Zoeiro", Age = 28 },
                    new SampleModel {Fullname = "Felipe Duarte", Nick = "Irmão de Zeca", Age = 29 },
                    new SampleModel {Fullname = "Antônio Cavalcante", Nick = "Toin", Age = 35 },
                    new SampleModel {Fullname = "Leonardo Martins", Nick = "Ninja", Age = 45 },
                    new SampleModel {Fullname = "Fernando Lúcio", Nick = "Adnet", Age = 17 }
                };

            Data = new ObservableCollection<SampleModel>(list);
        }


        public DelegateCommand AddRandomItemCommand { get; private set; }

        public DelegateCommand RemoveItemCommand { get; private set; }

        public DelegateCommand ResetListCommand { get; private set; }

        public DelegateCommand ChangeFirstItemCommand { get; private set; }

        private void InitializeCommands()
        {
            AddRandomItemCommand = new DelegateCommand(AddRandomItem);

            RemoveItemCommand = new DelegateCommand(RemoveItem, () => SelectedItem != null);

            ResetListCommand = new DelegateCommand(ResetList);

            ChangeFirstItemCommand = new DelegateCommand(ChangeFirstItem, () => Data.Count >= 1);
        }

        private void AddRandomItem()
        {
            Data.Add(new SampleModel { Fullname = "New Item" + count++ });
            ChangeFirstItemCommand.RaiseCanExecuteChanged();
        }

        private void RemoveItem()
        {
            Data.Remove(SelectedItem);
        }


        private void ResetList()
        {
            Data = new ObservableCollection<SampleModel>();
            SelectedItem = null;
        }

        private void ChangeFirstItem()
        {
            Data[0].Fullname = "Changed this item";
        }


        //properties
        private ObservableCollection<SampleModel> data;
        public ObservableCollection<SampleModel> Data
        {
            get { return data; }
            set { SetProperty(ref data, value); }
        }

        private SampleModel selectedItem = null;
        public SampleModel SelectedItem
        {
            get { return selectedItem; }
            set
            {
                SetProperty(ref selectedItem, value);
                ChangeFirstItemCommand.RaiseCanExecuteChanged();
                RemoveItemCommand.RaiseCanExecuteChanged();
            }
        }

    }
}
