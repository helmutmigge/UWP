﻿using Prism.Commands;
using Prism.Windows.Mvvm;
using Prism.Windows.Navigation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainingDay3.PrismSample.Models;
using TrainingDay3.PrismSample.Repositories;

namespace TrainingDay3.PrismSample.ViewModels
{
    public class MainPageViewModel : ViewModelBase
    {

        private INavigationService navigation;
        private IDataRepository dataRepository;

        public MainPageViewModel(INavigationService navigation, IDataRepository dataRepository)
        {
            this.navigation = navigation;
            this.dataRepository = dataRepository;

            InitializeCommands();
        }

        public override void OnNavigatedTo(NavigatedToEventArgs e, Dictionary<string, object> viewModelState)
        {
            base.OnNavigatedTo(e, viewModelState);

            Data = new ObservableCollection<Person>(dataRepository.ListPeople());
        }

        #region Commands
        public DelegateCommand AddPersonCommand { get; private set; }

        public DelegateCommand<string> SearchCommand { get; private set; }

        public DelegateCommand<Person> ShowPersonDetailsCommand { get; private set; } 

        private void InitializeCommands()
        {
            AddPersonCommand = new DelegateCommand(AddPerson);

            SearchCommand = new DelegateCommand<string>(Search);

            ShowPersonDetailsCommand = new DelegateCommand<Person>(ShowPersonDetails);
        }

        private void AddPerson()
        {
            //navigate to add page
            navigation.Navigate(PageTokens.AddPage, null);
        }

        private void Search(string query)
        {
            Data = new ObservableCollection<Person>(dataRepository.SearchPeople(query));
        }

        private void ShowPersonDetails(Person person)
        {
            navigation.Navigate(PageTokens.DetailsPage, person);
        }

        #endregion


        #region Properties
        private ObservableCollection<Person> data;
        public ObservableCollection<Person> Data
        {
            get { return data; }
            set { SetProperty(ref data, value); }
        }

        private string searchQuery;
        public string SearchQuery
        {
            get { return searchQuery; }
            set
            {
                SetProperty(ref searchQuery, value);
                Search(searchQuery);
            }
        }
        #endregion
    }
}
