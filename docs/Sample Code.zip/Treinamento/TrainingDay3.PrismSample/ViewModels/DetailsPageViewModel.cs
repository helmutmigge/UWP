﻿using Prism.Commands;
using Prism.Windows.Mvvm;
using Prism.Windows.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainingDay3.PrismSample.Models;
using TrainingDay3.PrismSample.Repositories;
using Windows.UI.Popups;

namespace TrainingDay3.PrismSample.ViewModels
{

    public class DetailsPageViewModel : ViewModelBase
    {
        private IDataRepository dataRepository;
        private INavigationService navigation;
        private int personIndex;

        public DetailsPageViewModel(INavigationService navigation, IDataRepository dataRepository)
        {
            this.navigation = navigation;
            this.dataRepository = dataRepository;

            InitializeCommands();
        }

        public override void OnNavigatedTo(NavigatedToEventArgs e, Dictionary<string, object> viewModelState)
        {
            base.OnNavigatedTo(e, viewModelState);

            if(e.Parameter != null && e.Parameter is Person)
            {
                var person = (Person)e.Parameter;
                personIndex = dataRepository.GetPersonIndex(person);

                SelectedPerson = person.ShallowCopy();
            }
        }
        

        #region Commands
        public DelegateCommand SavePersonCommand { get; private set; }

        public DelegateCommand CancelCommand { get; private set; }

        private void InitializeCommands()
        {
            SavePersonCommand = new DelegateCommand(
                () =>
                {
                    dataRepository.SavePerson(personIndex, SelectedPerson);
                    navigation.GoBack();
                });

            CancelCommand = new DelegateCommand(() => navigation.GoBack(), () => navigation.CanGoBack());
        }
        #endregion

        #region Properties
        private Person selectedPerson;

        public Person SelectedPerson
        {
            get { return selectedPerson; }
            set { SetProperty(ref selectedPerson, value); }
        }
        #endregion
    }
}
