﻿using Prism.Commands;
using Prism.Windows.Mvvm;
using Prism.Windows.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainingDay3.PrismSample.Models;
using TrainingDay3.PrismSample.Repositories;

namespace TrainingDay3.PrismSample.ViewModels
{
    public class AddPageViewModel : ViewModelBase
    {
        private IDataRepository dataRepository;
        private INavigationService navigation;

        public AddPageViewModel(INavigationService navigation, IDataRepository dataRepository)
        {
            this.navigation = navigation;
            this.dataRepository = dataRepository;

            NewPerson = new Person();

            InitializeCommands();
        }

        #region Commands
        public DelegateCommand SavePersonCommand { get; private set; }

        public DelegateCommand CancelCommand { get; private set; }

        private void InitializeCommands()
        {
            SavePersonCommand = new DelegateCommand(
                () =>
                {
                    dataRepository.AddPerson(NewPerson);
                    navigation.GoBack();
                });

            CancelCommand = new DelegateCommand(() => navigation.GoBack(), () => navigation.CanGoBack());
        }
        #endregion

        #region Properties
        private Person newPerson;

        public Person NewPerson
        {
            get { return newPerson; }
            set { SetProperty(ref newPerson, value); }
        }
        #endregion
    }
}
