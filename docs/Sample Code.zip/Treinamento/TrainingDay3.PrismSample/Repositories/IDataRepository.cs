﻿using System.Collections.Generic;
using TrainingDay3.PrismSample.Models;

namespace TrainingDay3.PrismSample.Repositories
{
    public interface IDataRepository
    {
        List<Person> ListPeople();
        List<Person> SearchPeople(string query);
        void AddPerson(Person newPerson);
        void SavePerson(int index, Person selectedPerson);
        int GetPersonIndex(Person person);

    }
}