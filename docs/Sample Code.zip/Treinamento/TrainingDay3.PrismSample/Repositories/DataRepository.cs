﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainingDay3.PrismSample.Models;

namespace TrainingDay3.PrismSample.Repositories
{
    public class DataRepository : IDataRepository
    {
        private List<Person> data;

        public DataRepository()
        {
            data = new List<Person>()
                {
                    new Person {Fullname = "Daniel Barros", Nick = "Urso", Age = 27 },
                    new Person {Fullname = "João Paulo", Nick = "JP", Age = 29 },
                    new Person {Fullname = "José Carlos", Nick = "Zoeiro", Age = 28 },
                    new Person {Fullname = "Felipe Duarte", Nick = "Irmão de Zeca", Age = 29 },
                    new Person {Fullname = "Antônio Cavalcante", Nick = "Toin", Age = 35 },
                    new Person {Fullname = "Leonardo Martins", Nick = "Ninja", Age = 45 },
                    new Person {Fullname = "Fernando Lúcio", Nick = "Adnet", Age = 17 }
                };
        }

        public List<Person> SearchPeople(string query)
        {
            query = query.ToLowerInvariant();
            return data.Where(obj => obj.Fullname.ToLowerInvariant().Contains(query)).ToList();
        }


        public List<Person> ListPeople()
        {
            return data;
        }

        public void AddPerson(Person person)
        {
            data.Add(person);
        }

        public void SavePerson(int index, Person person)
        {
            if (data.Count > index)
                data[index] = person;
        }
        public int GetPersonIndex(Person person)
        {
            return data.FindIndex(p => p == person);
        }
        
    }
}
