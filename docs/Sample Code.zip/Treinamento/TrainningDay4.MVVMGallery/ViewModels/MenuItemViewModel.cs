﻿using Prism.Commands;
using Prism.Windows.Mvvm;
using Prism.Windows.Navigation;
using System.Windows.Input;

namespace TrainningDay4.MVVMGallery.ViewModels
{
    public class MenuItemViewModel : ViewModelBase
    {
        private INavigationService navigationService;

        public MenuItemViewModel(INavigationService navigationService)
        {
            this.navigationService = navigationService;

            NavigateToCommand = new DelegateCommand(
                () => navigationService.Navigate(Page, null),
                () => !string.IsNullOrEmpty(Page));
        }


        public string DisplayName { get; set; }

        public int FontIcon { get; set; }

        public char FontIconAsChar { get { return (char)this.FontIcon; } }

        public ICommand NavigateToCommand { get; set; }

        public string Page { get; internal set; }

        public override string ToString()
        {
            return DisplayName;
        }
    }
}