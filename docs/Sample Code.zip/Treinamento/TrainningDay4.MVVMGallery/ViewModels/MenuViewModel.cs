﻿using Prism.Commands;
using Prism.Windows.Mvvm;
using Prism.Windows.Navigation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace TrainningDay4.MVVMGallery.ViewModels
{

    public class MenuViewModel : ViewModelBase
    {

        public MenuViewModel(INavigationService navigationService)
        {
            Commands = new ObservableCollection<MenuItemViewModel>
            {
                new MenuItemViewModel(navigationService)
                {
                    DisplayName = "Time",
                    FontIcon = (int)Symbol.Clock,
                    Page = PageTokens.TimePage
                },
                new MenuItemViewModel(navigationService)
                {
                    DisplayName = "Events",
                    FontIcon = (int)Symbol.CalendarDay
                    //Page = PageTokens.EventPage
                },
                new MenuItemViewModel(navigationService)
                {
                    DisplayName = "Folders",
                    FontIcon = (int)Symbol.Folder
                    //Page = PageTokens.FoldersPage
                },
                new MenuItemViewModel(navigationService)
                {
                    DisplayName = "Clouds",
                    FontIcon = 0xE753
                }
            };
        }

        public ObservableCollection<MenuItemViewModel> Commands { get; set; }

    }
}
