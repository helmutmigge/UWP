﻿using Prism.Windows.Mvvm;
using Prism.Windows.Navigation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainningDay4.MVVMGallery.Models;
using TrainningDay4.MVVMGallery.Services;

namespace TrainningDay4.MVVMGallery.ViewModels
{

    public class TimePageViewModel : ViewModelBase
    {
        private readonly IDataRepository dataRepository;

        public TimePageViewModel(IDataRepository dataRepository, INavigationService navigationService)
        {
            this.dataRepository = dataRepository;
            //Data = new ObservableCollection<MediaTimeGrouping>();
        }


        public override async void OnNavigatedTo(NavigatedToEventArgs e, Dictionary<string, object> viewModelState)
        {
            base.OnNavigatedTo(e, viewModelState);

            var list = await dataRepository.LoadMediasByTimeAsync(Models.Filters.All, Models.TimeGroup.Day);
            Data = new ObservableCollection<MediaTimeGrouping>(list);
        }

        // ItemsSource="{StaticResource CollectionData}"
        private ObservableCollection<MediaTimeGrouping> data;
        public ObservableCollection<MediaTimeGrouping> Data
        {
            get { return data; }
            set { SetProperty(ref data, value); }
        }
    }
}
