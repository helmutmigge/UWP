﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainningDay4.MVVMGallery.Models
{
    public class Folder
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Path { get; set; }

        public string CoverImage { get; set; }

        public int NumberOfMedias { get; set; }

        public string Token { get; set; }

        //Navigation Properties
        public virtual List<Media> Medias { get; set; }
    }
}
