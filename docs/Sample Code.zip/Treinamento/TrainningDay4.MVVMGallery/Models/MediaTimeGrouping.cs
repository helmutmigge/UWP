﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainningDay4.MVVMGallery.Models
{
    public class MediaTimeGrouping : ObservableCollection<Media>
    {
        public MediaTimeGrouping(DateTime date, List<Media> list, int timeGroup)
            : this(list)
        {
            Date = date;
            TimeGroup = timeGroup;
            GroupNumber = Int32.Parse(date.ToString("ddMMyyyy"));
        }

        public MediaTimeGrouping(int weekNumber, List<Media> list, int timeGroup)
            : this(list)
        {
            GroupNumber = weekNumber;
            TimeGroup = timeGroup;
        }

        private MediaTimeGrouping(List<Media> list)
            : base(list)
        {
            Location = String.Join(", ", this.Where(x => !string.IsNullOrEmpty(x.Location)).Select(x => x.Location).Distinct());
            IsAllGroupSelected = false;

            if (string.IsNullOrEmpty(Location))
                IsLoadingLocation = this.Any(x => x.Latitude != null);

        }

        public MediaTimeGrouping() { }

        public DateTime Date { get; set; }

        public string Location { get; set; }

        public int TimeGroup { get; set; }

        public int GroupNumber { get; set; }

        public bool IsLoadingLocation { get; set; }

        public bool IsAllGroupSelected { get; set; }

    }
}
