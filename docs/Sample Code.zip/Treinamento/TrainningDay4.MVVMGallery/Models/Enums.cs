﻿namespace TrainningDay4.MVVMGallery.Models
{
    public enum MediaTypes
    {
        Image,
        Video,
        Unknown
    }

    public enum Filters
    {
        All,
        PC,
        Device,
        Shared
    }

    public enum TimeGroup
    {
        Day = 2,
        Week = 1,
        Month = 0
    }
}