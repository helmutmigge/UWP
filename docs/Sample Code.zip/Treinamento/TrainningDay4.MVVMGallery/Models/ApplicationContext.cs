﻿using Microsoft.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainningDay4.MVVMGallery.Models
{
    public class ApplicationContext : DbContext
    {

        public DbSet<ContactModel> Contacts { get; set; }

        public DbSet<Device> Devices { get; set; }

        public DbSet<Media> Medias { get; set; }

        public DbSet<Event> Events { get; set; }

        public DbSet<Folder> Folders { get; set; }

        public DbSet<EventMedia> EventMedias { get; set; }

        public DbSet<EventContact> EventContacts { get; set; }




        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite($"Filename=PCGallery_MVVM.db");
        }
       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EventMedia>().HasKey(x => new { x.EventId, x.MediaId });
            modelBuilder.Entity<EventContact>().HasKey(x => new { x.EventId, x.ContactId });
        }
    }
}
