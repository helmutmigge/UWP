﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainningDay4.MVVMGallery.Models
{
    public class EventMedia
    {
        public int EventId { get; set; }

        public int MediaId { get; set; }

        public Event @Event { get; set; }
                
        public Media Media { get; set; }
    }
}