﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace TrainningDay4.MVVMGallery.Models
{
    public class Contact
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public string Region { get; set; }

        public string ProfileImage { get; set; }

        public string PhoneNumber { get; set; }

        
        //Navigation Properties
        public virtual List<EventContact> EventContacts { get; set; }
    }


    public class ContactModel : INotifyPropertyChanged
    {


        [Key]
        public int Id { get; set; }

        private string _fullName;
        /// <summary>
        /// Full Name 
        /// </summary>
        public string FullName
        {
            get
            {
                return _fullName;
            }
            set
            {
                if (!Equals(_fullName, value))
                    _fullName = value;
            }
        }

        /// <summary>
        /// MSISDN
        /// </summary>
        public string MSISDN { get; set; }

        private bool _isJoined;
        /// <summary>
        /// To show the SMS Icon
        /// </summary>
        public bool IsJoined
        {
            get
            {
                return _isJoined;
            }
            set
            {
                if (_isJoined == value) return;
                _isJoined = value;
                NotifyPropertyChanged();
            }
        }

        private bool _isChecked;
        /// <summary>
        /// To check it is Selected or not
        /// </summary>
        public bool IsChecked
        {
            get
            {
                return _isChecked;
            }
            set
            {
                if (_isChecked == value) return;
                _isChecked = value;
                NotifyPropertyChanged();
            }
        }

        private string _imageUrl;
        /// <summary>
        /// url to show profile Image
        /// </summary>
        public string ImageUrl
        {
            get
            {
                return _imageUrl;
            }
            set
            {
                if (_imageUrl != value)
                    _imageUrl = value;
            }
        }

        /*private ImageSource _profileImage;
        /// <summary>
        /// url to show profile Image
        /// </summary>
        public ImageSource ProfileImage
        {
            get
            {
                return _profileImage;
            }
            set
            {
                if (_profileImage != value)
                    _profileImage = value;
            }
        }
        */
        private bool _isLastItemInGroup;
        /// <summary>
        /// To not show Separator in View
        /// </summary>
        public bool IsLastItemInGroup
        {
            get
            {
                return _isLastItemInGroup;
            }
            set
            {
                if (_isLastItemInGroup == value) return;
                _isLastItemInGroup = value;
                NotifyPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
