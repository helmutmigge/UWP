﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainningDay4.MVVMGallery.Models
{
    public class Event
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string CoverImage { get; set; }

        public int NumberOfMedias { get; set; }

        public int NumberOfContacts { get; set; }

        public bool IsLocal { get; set; }

        public bool IsShared { get; set; }

        public bool IsHidden { get; set; }


        //Navigation Properties

        public virtual List<EventMedia> EventMedias { get; set; }

        public virtual List<EventContact> EventContacts { get; set; }
    }
}
