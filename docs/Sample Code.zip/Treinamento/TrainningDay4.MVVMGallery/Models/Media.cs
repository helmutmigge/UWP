﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainningDay4.MVVMGallery.Models
{
    public class Media
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Filename { get; set; }

        [Required]
        public string Path { get; set; }

        public string Location { get; set; }

        public bool IsFavorite { get; set; }

        public DateTime TakenDate { get; set; }

        public string TakenDevice { get; set; }

        public bool IsLocal { get; set; }

        public bool IsHidden { get; set; }

        public MediaTypes MediaType { get; set; }

        public int FolderId { get; set; }

        [NotMapped]
        public double? Latitude { get; set; }

        [NotMapped]
        public double? Longitude { get; set; }

        //Navigation Properties

        public virtual Folder Folder { get; set; }

        public virtual List<EventMedia> EventMedias { get; set; }

        public override bool Equals(object obj)
        {
            var tmp = obj as Media;
            if (tmp == null)
                throw new ArgumentException("obj not is a Media");

            return Path == tmp.Path;
        }
    }
}
