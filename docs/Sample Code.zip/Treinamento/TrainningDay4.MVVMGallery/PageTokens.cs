﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainningDay4.MVVMGallery
{
    public static class PageTokens
    {
        public const string MainPage = "Main";
        public const string TimePage = "Time";
        public const string EventPage = "Event";
        public const string FoldersPage = "Time";
        public const string ExpansionPage = "Expansion";

    }
}
