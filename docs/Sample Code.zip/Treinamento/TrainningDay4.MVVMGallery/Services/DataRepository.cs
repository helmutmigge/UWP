﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainningDay4.MVVMGallery.Models;
using Microsoft.Data.Entity;

namespace TrainningDay4.MVVMGallery.Services
{
    public class DataRepository : IDataRepository
    {
        public async Task<List<MediaTimeGrouping>> LoadMediasByTimeAsync(Filters filter, TimeGroup timeGroup)
        {
            using (var db = new ApplicationContext())
            {
                var query = db.Medias
                    .Where(e => (filter == Filters.All ||
                                (e.IsLocal && filter == Filters.PC) ||
                                (!e.IsLocal && filter == Filters.Device)) && !e.IsHidden);

                return await GroupByTimeGroupAsync(query, timeGroup);
            }
        }


        private async Task<List<MediaTimeGrouping>> GroupByTimeGroupAsync(IQueryable<Media> query, TimeGroup timeGroup)
        {
            switch (timeGroup)
            {
                case TimeGroup.Day:
                    return await query.GroupBy(g => new DateTime(g.TakenDate.Year, g.TakenDate.Month, g.TakenDate.Day)).OrderByDescending(obj => obj.Key)
                    .Select(s => new MediaTimeGrouping(s.Key, s.OrderByDescending(x => x.TakenDate).ToList(), (int)timeGroup))
                        .ToListAsync();

                case TimeGroup.Week:
                    var dfi = DateTimeFormatInfo.CurrentInfo;
                    return await query.GroupBy(g => (g.TakenDate.Year * 1000) + (dfi.Calendar.GetWeekOfYear(g.TakenDate, CalendarWeekRule.FirstDay, DayOfWeek.Monday))).OrderByDescending(obj => obj.Key)
                    .Select(s => new MediaTimeGrouping(s.Key, s.OrderByDescending(x => x.TakenDate).ToList(), (int)timeGroup))
                        .ToListAsync();

                case TimeGroup.Month:
                    return await query.GroupBy(g => new DateTime(g.TakenDate.Year, g.TakenDate.Month, 1)).OrderByDescending(obj => obj.Key)
                    .Select(s => new MediaTimeGrouping(s.Key, s.OrderByDescending(x => x.TakenDate).ToList(), (int)timeGroup))
                        .ToListAsync();
                default:
                    return null;
            }
        }
    }
}
