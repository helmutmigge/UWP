﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TrainningDay4.MVVMGallery.Models;

namespace TrainningDay4.MVVMGallery.Services
{
    public interface IDataRepository
    {
        Task<List<MediaTimeGrouping>> LoadMediasByTimeAsync(Filters filter, TimeGroup timeGroup);
    }
}